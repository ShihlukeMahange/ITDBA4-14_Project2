# ITBDA4-14 Project 2 — R-only submission

**All four assignment questions are consolidated into one R file:** `ITBDA4-14_Project_2_All_Questions.R`.
This repository also contains the supplied data archives, four R Markdown notebooks, and the written Word report.

## Running in RStudio
1. Open RStudio and set the working directory to this repository folder (the folder containing the `.R` file).
2. Run once: `install.packages(c("tm", "topicmodels", "slam", "wordcloud", "rvest", "stopwords", "DBI", "RPostgres"))`
3. Load the code: `source("ITBDA4-14_Project_2_All_Questions.R")`
4. Run each question **separately**:
   - Q1: `run_q1("local", "africa")` (or replace the word; for Hadoop use `run_q1("hadoop", "africa")`)
   - Q2: `run_q2(n_topics = 4, k_words = 10)`
   - Q3: `run_q3()`
   - Q4 without PostgreSQL: `run_q4(load_to_db = FALSE)`
   - Q4 with PostgreSQL: `run_q4(load_to_db = TRUE)`

**Q1**: The local runner produces a local proof of concept, not evidence of a distributed Hadoop job. Hadoop mode requires Hadoop Streaming, Rscript installed on workers, an HDFS cluster, and `HADOOP_STREAMING_JAR` set to the real JAR path.

**Q2**: Uses the ten supplied news documents. Runs R package `topicmodels`, so final model output needs to be generated in RStudio.

**Q3**: Reads one permitted public webpage as an educational example. Internet and compliance with website robots/usage rules are required. Website selectors can change.

**Q4**: Reads the educational `books.toscrape.com` sample website; saves `q4_output/books_cleaned.csv`. Database import requires a running PostgreSQL server, a database named `project2`, and `PGDATABASE`, `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD` environment variables (do NOT commit passwords).

## Notebooks
`notebooks/` includes four `.Rmd` **R Notebooks** covering the flow of analytics for Q1–Q4. Open each in RStudio and run/preview with the required tools installed. The notebook files are source templates and do not constitute screenshots of a successful live run.

## Files
- `ITBDA4-14_Project_2_All_Questions.R` — full R-only implementation, with subquestion labels.
- `map_reduce_test_docs.zip` and `news.zip` — copies of the assignment's supplied archives (also in `datasets/`).
- `notebooks/Question_1_MapReduce.Rmd` to `Question_4_ETL_PostgreSQL.Rmd` — R Notebooks.
- `documentation/ITBDA4-14_Project_2_R_Only_Annotated.docx` — written report.

## Before final submission
- Run the applicable code and save genuine result screenshots in the documentation.
- Verify the R plots, Hadoop MapReduce job, and PostgreSQL output on your environment.
- Commit the project contents (not just the `.R` file) to a GitHub repository and submit that repository URL.
