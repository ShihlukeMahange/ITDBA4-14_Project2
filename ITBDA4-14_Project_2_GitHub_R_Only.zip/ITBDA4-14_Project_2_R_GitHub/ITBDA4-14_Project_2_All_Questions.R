# ================================================================
# ITBDA4-14 PROJECT 2 - ALL FOUR QUESTIONS (R ONLY)
# Single R source file for Question 4.4 GitHub submission.
# ================================================================
# THIS FILE CONTAINS:
# Q1: 1.1, 1.2, 1.3, 1.4 - Hadoop Streaming in R
# Q2: 2.1, 2.2, 2.3 - News preprocessing and LDA
# Q3: 3.1, 3.2, 3.3 - Web text and two summary methods
# Q4: 4.1, 4.2, 4.3 - Web-to-PostgreSQL ETL
# Q4.4: Publish this R file, datasets, notebooks, and documentation.
# ================================================================
# Place news.zip and map_reduce_test_docs.zip in the SAME folder
# as this .R file. Outputs will be generated into q1/q2/q3/q4 folders.
# Install packages ONCE in RStudio before running:
# install.packages(c("tm", "topicmodels", "slam", "wordcloud",
#                    "rvest", "stopwords", "DBI", "RPostgres"))
#
# RStudio: source("ITBDA4-14_Project_2_All_Questions.R")
#          run_q1("local", "africa")  # demo keyword; change freely
#          run_q2(n_topics = 4, k_words = 10)
#          run_q3()
#          run_q4(load_to_db = FALSE) # scrape + clean without database
#          run_q4(load_to_db = TRUE)  # requires PostgreSQL running
#
# Terminal:
# Rscript ITBDA4-14_Project_2_All_Questions.R q1-local africa
# Rscript ITBDA4-14_Project_2_All_Questions.R q1-hadoop africa
# Rscript ITBDA4-14_Project_2_All_Questions.R q2
# Rscript ITBDA4-14_Project_2_All_Questions.R q3
# Rscript ITBDA4-14_Project_2_All_Questions.R q4-scrape
# Rscript ITBDA4-14_Project_2_All_Questions.R q4
# NOTE: Q1.1 additionally requires the diagram; the code handles data.
# NOTE: Some tasks need internet, Hadoop and/or PostgreSQL to run.
# ================================================================

# ===================================================================
# QUESTION 1 (25 MARKS) - MAPREDUCE KEYWORD SEARCH
# ===================================================================

# QUESTION 1.1 - PREPARE TEXT AND PRESERVE ORIGINAL ROWS
# Column = 1-based WORD position on the row, not character position.
word_columns <- function(sentence, target) {
  words <- regmatches(sentence,
                      gregexpr("[[:alnum:]]+", sentence, perl = TRUE))[[1]]
  which(tolower(words) == tolower(target))
}

# Convert each document into file_name<TAB>row_number<TAB>text.
# This preserves rows even if Hadoop divides input between mappers.
prepare_input <- function() {
  zip_file <- "map_reduce_test_docs.zip"
  if (!file.exists(zip_file)) stop("Place map_reduce_test_docs.zip here.")
  dir.create("q1_input", showWarnings = FALSE)
  unzip(zip_file, exdir = "q1_input")
  files <- list.files("q1_input", "\\.txt$", full.names = TRUE,
                      recursive = TRUE)
  files <- files[!grepl("__MACOSX", files)]
  files <- sort(files)
  if (!length(files)) stop("No text documents were found.")
  records <- unlist(lapply(files, function(f) {
    lines <- readLines(f, warn = FALSE, encoding = "UTF-8")
    paste(basename(f), seq_along(lines),
          gsub("\t", " ", lines, fixed = TRUE), sep = "\t")
  }), use.names = FALSE)
  writeLines(records, "q1_prepared.tsv", useBytes = TRUE)
  cat("Prepared", length(files), "documents.\n")
  "q1_prepared.tsv"
}

# QUESTION 1.2 - MAPPER IMPLEMENTATION (9 MARKS)
# Mapper receives one prepared input record at a time.
# It emits: document|row|word_column<TAB>1.
mapper <- function() {
  target <- Sys.getenv("SEARCH_KEYWORD")
  if (!nzchar(target)) stop("Missing SEARCH_KEYWORD environment variable.")
  con <- file("stdin", "r")
  on.exit(close(con))
  repeat {
    rec <- readLines(con, n = 1, warn = FALSE)
    if (!length(rec)) break
    fields <- strsplit(rec, "\t", fixed = TRUE)[[1]]
    if (length(fields) < 2) next
    document <- fields[1]
    row <- suppressWarnings(as.integer(fields[2]))
    sentence <- if (length(fields) >= 3)
      paste(fields[-c(1, 2)], collapse = "\t") else ""
    if (is.na(row)) next
    for (column in word_columns(sentence, target)) {
      cat(document, "|", row, "|", column, "\t1\n", sep = "")
    }
  }
}

# QUESTION 1.3 - REDUCER IMPLEMENTATION (5 MARKS)
# Reducer receives Hadoop-sorted mapper keys; combines duplicates.
reducer <- function() {
  con <- file("stdin", "r")
  on.exit(close(con))
  current_key <- ""
  total <- 0L
  repeat {
    rec <- readLines(con, n = 1, warn = FALSE)
    if (!length(rec)) break
    fields <- strsplit(rec, "\t", fixed = TRUE)[[1]]
    if (length(fields) != 2) next
    key <- fields[1]
    count <- suppressWarnings(as.integer(fields[2]))
    if (is.na(count)) next
    if (nzchar(current_key) && key != current_key) {
      cat(current_key, "\t", total, "\n", sep = "")
      total <- 0L
    }
    current_key <- key
    total <- total + count
  }
  if (nzchar(current_key)) {
    cat(current_key, "\t", total, "\n", sep = "")
  }
}

# QUESTION 1.1 - LOCAL DEMONSTRATION OF THE SEARCH LOGIC (7 MARKS)
# Local proof of concept using the exact same token/row logic.
# This is NOT evidence that Hadoop has been executed.
run_local <- function(target) {
  prepared <- prepare_input()
  records <- readLines(prepared, warn = FALSE, encoding = "UTF-8")
  matches <- list()
  for (rec in records) {
    fields <- strsplit(rec, "\t", fixed = TRUE)[[1]]
    if (length(fields) < 2) next
    sentence <- if (length(fields) >= 3)
      paste(fields[-c(1, 2)], collapse = "\t") else ""
    for (column in word_columns(sentence, target)) {
      matches[[length(matches) + 1]] <- data.frame(
        file_name = fields[1], row = as.integer(fields[2]), column = column
      )
    }
  }
  if (length(matches)) {
    result <- do.call(rbind, matches)
    result <- result[order(result$file_name, result$row,
                           result$column), ]
  } else {
    result <- data.frame(file_name = character(), row = integer(),
                         column = integer())
  }
  write.csv(result, "q1_keyword_results.csv", row.names = FALSE)
  print(result, row.names = FALSE)
  cat("Total matching word positions:", nrow(result), "\n")
}

# QUESTION 1.4 - HADOOP JOB CONFIGURATION (4 MARKS)
# Hadoop Streaming launches Rscript for the mapper and reducer.
# Requires Hadoop, HDFS, Rscript on every Hadoop worker, and the JAR path.
run_hadoop <- function(target) {
  prepared <- prepare_input()
  jar <- Sys.getenv("HADOOP_STREAMING_JAR")
  if (!nzchar(jar) || !file.exists(jar))
    stop("Set HADOOP_STREAMING_JAR to the Hadoop Streaming .jar path.")
  if (!nzchar(Sys.which("hdfs")) || !nzchar(Sys.which("hadoop")))
    stop("Hadoop and HDFS must be available on PATH.")
  input_dir <- "/user/project2/input"
  output_dir <- "/user/project2/output"
  system2("hdfs", c("dfs", "-mkdir", "-p", input_dir))
  system2("hdfs", c("dfs", "-put", "-f", shQuote(prepared),
                    paste0(input_dir, "/q1_prepared.tsv")))
  system2("hdfs", c("dfs", "-rm", "-r", "-f", output_dir),
          stdout = FALSE, stderr = FALSE)
  job_args <- c(
    "jar", shQuote(jar), "-D", "mapreduce.job.name=RKeywordSearch",
    "-D", "mapreduce.job.reduces=1",
    "-D", "mapreduce.map.memory.mb=512",
    "-D", "mapreduce.reduce.memory.mb=512",
    "-files", shQuote(normalizePath("ITBDA4-14_Project_2_All_Questions.R")),
    "-mapper", shQuote("Rscript ITBDA4-14_Project_2_All_Questions.R q1-mapper"),
    "-reducer", shQuote("Rscript ITBDA4-14_Project_2_All_Questions.R q1-reducer"),
    "-cmdenv", shQuote(paste0("SEARCH_KEYWORD=", target)),
    "-input", paste0(input_dir, "/q1_prepared.tsv"),
    "-output", output_dir
  )
  status <- system2("hadoop", job_args)
  if (status != 0) stop("Hadoop Streaming failed. Check the Hadoop logs.")
  cat("Hadoop result files are at:", output_dir, "\n")
  system2("hdfs", c("dfs", "-cat", paste0(output_dir, "/part-*")))
}
# QUESTION 1 - RUNNER / DYNAMIC KEYWORD INPUT
run_q1 <- function(mode = "local", keyword = "") {
  if (!nzchar(keyword)) keyword <- readline("Enter the keyword to search: ")
  if (!grepl("^[[:alpha:]]+$", keyword))
    stop("Enter one alphabetic keyword, e.g. africa.")
  if (mode == "local") run_local(keyword)
  else if (mode == "hadoop") run_hadoop(keyword)
  else stop("Question 1 mode must be 'local' or 'hadoop'.")
}

# ===================================================================
# QUESTION 2 (20 MARKS) - LDA TOPIC MODELLING
# ===================================================================
run_q2 <- function(n_topics = 4, k_words = 10) {
  library(tm)
  library(topicmodels)
  library(slam)
  library(wordcloud)

  set.seed(42)
  dir.create("q2_news", showWarnings = FALSE)
  dir.create("q2_output", showWarnings = FALSE)
  if (!file.exists("news.zip")) stop("Place news.zip in this folder.")
  unzip("news.zip", exdir = "q2_news")
  files <- sort(list.files("q2_news", "\\.txt$", full.names = TRUE,
                           recursive = TRUE))
  if (length(files) == 0) stop("No articles found in news.zip.")

  # QUESTION 2.1 (5 MARKS): Build a two-column data frame and denoise the news text.
  news <- data.frame(
    file_name = basename(files),
    content = vapply(files, function(path) {
      paste(readLines(path, warn = FALSE, encoding = "UTF-8"),
            collapse = " ")
    }, character(1)),
    stringsAsFactors = FALSE
  )
  clean_text <- function(text) {
    text <- tolower(text)
    text <- gsub("https?://[^ ]+", " ", text)
    text <- gsub("[^[:alpha:] ]", " ", text)
    text <- gsub("[[:space:]]+", " ", text)
    trimws(text)
  }
  news$clean_content <- vapply(news$content, clean_text, character(1))
  write.csv(news[, c("file_name", "content")],
            "q2_output/news_dataframe.csv", row.names = FALSE)
  write.csv(news, "q2_output/news_cleaned.csv", row.names = FALSE)
  cat("Articles loaded:", nrow(news), "\n")

  # QUESTION 2.2 (9 MARKS): Document-term matrix, LDA model and topic probabilities.
  corpus <- VCorpus(VectorSource(news$clean_content))
  corpus <- tm_map(corpus, removeWords, stopwords("english"))
  corpus <- tm_map(corpus, stripWhitespace)
  dtm <- DocumentTermMatrix(corpus, control = list(wordLengths = c(3, Inf)))
  nonempty <- slam::row_sums(dtm) > 0
  dtm <- dtm[nonempty, ]
  if (nrow(dtm) < n_topics) stop("Choose n_topics <= non-empty documents.")
  if (ncol(dtm) < k_words) stop("Not enough terms for chosen k_words.")
  lda <- LDA(dtm, k = n_topics, method = "Gibbs",
             control = list(seed = 42, burnin = 500, iter = 1000, thin = 50))
  beta <- posterior(lda)$terms   # P(word | topic)
  gamma <- posterior(lda)$topics # P(topic | document)

  top_words <- do.call(rbind, lapply(seq_len(n_topics), function(t) {
    ids <- order(beta[t, ], decreasing = TRUE)[seq_len(k_words)]
    data.frame(topic = paste("Topic", t), word = colnames(beta)[ids],
               probability = beta[t, ids], row.names = NULL)
  }))
  print(top_words)
  write.csv(top_words, "q2_output/topic_top_words.csv", row.names = FALSE)
  rownames(gamma) <- news$file_name[nonempty]
  write.csv(gamma, "q2_output/document_topic_probabilities.csv")

  # QUESTION 2.3 (6 MARKS): Visualisation A - topic-specific horizontal bar charts.
  # Visualisation B - topic-specific word clouds.
  for (t in seq_len(n_topics)) {
    part <- top_words[top_words$topic == paste("Topic", t), ]
    png(sprintf("q2_output/topic_%s_bar.png", t), width = 1100, height = 700)
    par(mar = c(5, 11, 4, 2))
    barplot(rev(part$probability), names.arg = rev(part$word),
            horiz = TRUE, las = 1, col = "grey35",
            main = paste("LDA Topic", t, "- top words"),
            xlab = "Probability of word given topic", ylab = "Keyword")
    dev.off()
    png(sprintf("q2_output/topic_%s_wordcloud.png", t),
        width = 1100, height = 700)
    wordcloud(words = part$word, freq = part$probability,
              max.words = k_words, min.freq = 0, random.order = FALSE,
              colors = c("black", "grey35", "grey60"))
    title(main = paste("LDA Topic", t, "- word cloud"))
    dev.off()
  }
  cat("Saved cleaned data, topic distributions and two graph types.\n")
}

# ===================================================================
# QUESTION 3 (30 MARKS) - WEB TEXT AND SUMMARIES
# ===================================================================
run_q3 <- function() {
  library(rvest)
  library(stopwords)
  library(wordcloud)

  dir.create("q3_output", showWarnings = FALSE)
  url <- "https://en.wikipedia.org/wiki/Natural_language_processing"
  # Educational, one-page collection only: check Wikipedia's usage rules,
  # credit the source, and do not repeatedly crawl the website.
  page <- read_html(url)
  paragraphs <- html_text2(html_elements(page, ".mw-parser-output p"))
  if (length(paragraphs) < 5)
    paragraphs <- html_text2(html_elements(page, "p"))
  paragraphs <- trimws(paragraphs)
  paragraphs <- head(paragraphs[nchar(paragraphs) >= 70], 80)
  if (length(paragraphs) < 5) stop("Check page structure or connection.")

  # QUESTION 3.1 (7 MARKS): Webpage text in an R data frame.
  web_data <- data.frame(paragraph_id = seq_along(paragraphs),
                         source_url = url, raw_text = paragraphs)

  # QUESTION 3.2 (5 MARKS): Preprocessing: remove citations, URLs, extra spaces and empty text.
  preprocess <- function(text) {
    text <- gsub("\\[[0-9, ]+\\]", " ", text)
    text <- gsub("https?://[^ ]+", " ", text)
    text <- gsub("[[:space:]]+", " ", text)
    trimws(text)
  }
  web_data$clean_text <- vapply(web_data$raw_text, preprocess,
                                character(1))
  web_data <- web_data[nchar(web_data$clean_text) > 30, ]
  write.csv(web_data, "q3_output/web_text.csv", row.names = FALSE)

  sentences <- unlist(strsplit(paste(web_data$clean_text, collapse = " "),
                               "(?<=[.!?])\\s+", perl = TRUE))
  sentences <- trimws(sentences)
  sentences <- sentences[nchar(sentences) >= 35]
  if (length(sentences) < 5) stop("Not enough text for summaries.")

  stop_list <- c(stopwords("en"), "nlp", "also", "however")
  tokenise <- function(x) {
    x <- tolower(gsub("[^[:alpha:] ]", " ", x))
    words <- unlist(strsplit(trimws(x), "[[:space:]]+"))
    words[nchar(words) > 2 & !(words %in% stop_list)]
  }
  tokens <- lapply(sentences, tokenise)
  frequency <- sort(table(unlist(tokens)), decreasing = TRUE)
  if (!length(frequency)) stop("No meaningful terms found.")

  # QUESTION 3.3 (18 MARKS), METHOD A: rank sentences by average word frequency.
  score_a <- vapply(tokens, function(x) {
    if (!length(x)) return(0)
    mean(as.numeric(frequency[x]))
  }, numeric(1))

  # QUESTION 3.3 (18 MARKS), METHOD B: rank sentences by their average TF-IDF weights.
  N <- length(tokens)
  document_frequency <- table(unlist(lapply(tokens, unique)))
  score_b <- vapply(tokens, function(x) {
    if (!length(x)) return(0)
    tf <- table(x) / length(x)
    idf <- log((N + 1) / (as.numeric(document_frequency[names(tf)]) + 1)) + 1
    sum(as.numeric(tf) * idf)
  }, numeric(1))

  select_summary <- function(scores, n = 5) {
    ids <- sort(head(order(scores, decreasing = TRUE), n))
    paste(sentences[ids], collapse = " ")
  }
  summary_frequency <- select_summary(score_a)
  summary_tfidf <- select_summary(score_b)
  writeLines(summary_frequency, "q3_output/summary_frequency.txt")
  writeLines(summary_tfidf, "q3_output/summary_tfidf.txt")
  write.csv(data.frame(sentence = sentences,
                       frequency_score = score_a, tfidf_score = score_b),
            "q3_output/summary_scores.csv", row.names = FALSE)
  cat("FREQUENCY SUMMARY:\n", summary_frequency, "\n\n")
  cat("TF-IDF SUMMARY:\n", summary_tfidf, "\n")

  # Fully labelled graph 1: word frequencies.
  png("q3_output/top_keywords.png", width = 1100, height = 700)
  par(mar = c(5, 12, 4, 2))
  top <- rev(head(frequency, 15))
  barplot(top, horiz = TRUE, las = 1, col = "grey35",
          main = "Wikipedia NLP article: 15 most common keywords",
          xlab = "Number of occurrences", ylab = "Keyword")
  dev.off()

  # Fully labelled graph 2: sentence importance (both methods).
  png("q3_output/summary_scores.png", width = 1100, height = 700)
  plot(seq_along(score_a), score_a, type = "l", lwd = 2,
       xlab = "Sentence position in the article",
       ylab = "Sentence importance score",
       main = "Extractive summary scores: frequency and TF-IDF")
  lines(seq_along(score_b), score_b, lwd = 2, lty = 2)
  legend("topright", legend = c("Average frequency", "TF-IDF"),
         lty = c(1, 2), lwd = 2, bty = "n")
  dev.off()

  # Optional third figure: a keyword word cloud.
  png("q3_output/wordcloud.png", width = 1100, height = 700)
  set.seed(42)
  wordcloud(words = names(frequency), freq = as.numeric(frequency),
            max.words = 80, min.freq = 1, random.order = FALSE,
            colors = c("black", "grey40", "grey65"))
  title(main = "Wikipedia NLP article: keyword word cloud")
  dev.off()
}

# ===================================================================
# QUESTION 4 (25 MARKS) - EXTRACT, TRANSFORM, LOAD
# ===================================================================
run_q4 <- function(load_to_db = TRUE) {
  library(rvest)

  dir.create("q4_output", showWarnings = FALSE)
  url <- "https://books.toscrape.com/catalogue/page-1.html"
  page <- read_html(url)
  book_nodes <- html_elements(page, "article.product_pod")
  if (length(book_nodes) < 20) stop("Could not retrieve 20 book records.")

  get_text <- function(node, selector) {
    item <- html_element(node, selector)
    if (inherits(item, "xml_missing")) return(NA_character_)
    trimws(html_text2(item))
  }
  get_attribute <- function(node, selector, attribute) {
    item <- html_element(node, selector)
    if (inherits(item, "xml_missing")) return(NA_character_)
    html_attr(item, attribute)
  }

  # QUESTION 4.1 (8 MARKS): Raw attributes retain real web formatting, including GBP signs,
  # abbreviated titles and word-based rating labels (noise to clean).
  raw_books <- do.call(rbind, lapply(book_nodes, function(node) {
    link <- get_attribute(node, "h3 a", "href")
    rating_class <- get_attribute(node, "p.star-rating", "class")
    data.frame(
      book_url = if (is.na(link)) NA_character_
        else xml2::url_absolute(link, url),
      visible_title = get_text(node, "h3 a"),
      full_title = get_attribute(node, "h3 a", "title"),
      price_raw = get_text(node, ".price_color"),
      rating_raw = if (is.na(rating_class)) NA_character_
        else tail(strsplit(rating_class, " +")[[1]], 1),
      stock_raw = get_text(node, ".availability"),
      stringsAsFactors = FALSE
    )
  }))
  write.csv(raw_books, "q4_output/books_raw.csv", row.names = FALSE)

  # QUESTION 4.2 (4 MARKS): Regex denoising, missing-value treatment and duplicate removal.
  rating_lookup <- c(One = 1L, Two = 2L, Three = 3L,
                     Four = 4L, Five = 5L)
  books <- data.frame(
    book_url = raw_books$book_url,
    book_title = ifelse(is.na(raw_books$full_title) |
                        !nzchar(raw_books$full_title),
                        raw_books$visible_title, raw_books$full_title),
    price_gbp = suppressWarnings(as.numeric(
      gsub("[^0-9.]", "", raw_books$price_raw))),
    rating = as.integer(rating_lookup[raw_books$rating_raw]),
    in_stock = grepl("in stock", raw_books$stock_raw, ignore.case = TRUE)
  )
  books$book_title <- trimws(gsub("[[:space:]]+", " ", books$book_title))
  books$book_title[is.na(books$book_title) |
                   !nzchar(books$book_title)] <- "Unknown title"
  if (all(is.na(books$price_gbp)) || all(is.na(books$rating)))
    stop("No numeric prices/ratings found. Inspect website selectors.")
  books$price_gbp[is.na(books$price_gbp)] <-
    median(books$price_gbp, na.rm = TRUE)
  books$rating[is.na(books$rating)] <-
    as.integer(round(median(books$rating, na.rm = TRUE)))
  books <- books[!is.na(books$book_url) & nzchar(books$book_url), ]
  books <- books[!duplicated(books$book_url), ]
  stopifnot(nrow(books) >= 20, !anyNA(books$price_gbp),
            !anyNA(books$rating))
  write.csv(books, "q4_output/books_cleaned.csv", row.names = FALSE)
  cat("Raw rows:", nrow(raw_books), " Clean rows:", nrow(books), "\n")

  # Preview graph generated directly from the cleaned R data.
  png("q4_output/average_price_by_rating.png", width = 1100, height = 700)
  means <- tapply(books$price_gbp, books$rating, mean)
  barplot(means, col = "grey35", main = "Mean book price by star rating",
          xlab = "Star rating", ylab = "Average price (GBP)")
  dev.off()

  if (load_to_db) {
    library(DBI)
    library(RPostgres)
    # QUESTION 4.3 (7 MARKS): Connect to PostgreSQL, create relational table, load and analyse.
    # Credentials belong in environment variables, never in a GitHub project.
    con <- dbConnect(RPostgres::Postgres(),
                     dbname = Sys.getenv("PGDATABASE", "project2"),
                     host = Sys.getenv("PGHOST", "localhost"),
                     port = as.integer(Sys.getenv("PGPORT", "5432")),
                     user = Sys.getenv("PGUSER", "postgres"),
                     password = Sys.getenv("PGPASSWORD"))
    tryCatch({
      dbExecute(con, paste(
        "CREATE TABLE IF NOT EXISTS books (",
        "book_url TEXT PRIMARY KEY,",
        "book_title TEXT NOT NULL,",
        "price_gbp NUMERIC(10,2) NOT NULL,",
        "rating INTEGER NOT NULL,",
        "in_stock BOOLEAN NOT NULL)"
      ))
      dbExecute(con, "TRUNCATE TABLE books")
      dbWriteTable(con, "books", books, append = TRUE, row.names = FALSE)

      # Investigation 1: how much do books cost overall?
      query_1 <- paste(
        "SELECT COUNT(*) AS book_count,",
        "ROUND(AVG(price_gbp),2) AS average_gbp,",
        "MIN(price_gbp) AS minimum_gbp,",
        "MAX(price_gbp) AS maximum_gbp FROM books"
      )
      result_1 <- dbGetQuery(con, query_1)
      print(result_1)
      write.csv(result_1, "q4_output/sql_prices.csv", row.names = FALSE)

      # Investigation 2: does mean price differ by displayed rating?
      query_2 <- paste(
        "SELECT rating, COUNT(*) AS book_count,",
        "ROUND(AVG(price_gbp),2) AS average_gbp",
        "FROM books GROUP BY rating ORDER BY rating"
      )
      result_2 <- dbGetQuery(con, query_2)
      print(result_2)
      write.csv(result_2, "q4_output/sql_rating_summary.csv", row.names = FALSE)
    }, finally = dbDisconnect(con))
    cat("Created cleaned CSV, R graph and PostgreSQL query results.\n")
  } else {
    cat("Q4 scraping and cleaning complete. PostgreSQL stage skipped.\n")
  }
}

# QUESTION 4.4 (6 MARKS) - GITHUB SUBMISSION
# Upload this file, the two provided ZIP datasets, all four .Rmd notebooks,
# and the assignment documentation to the SAME GitHub repository.
# Instructions are in README.md in the packaged project folder.

# ================================================================
# COMMAND-LINE DISPATCH (does not run when simply sourced in RStudio)
# ================================================================
if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  task <- if (length(args)) args[1] else ""
  keyword <- if (length(args) >= 2L) args[2] else ""
  if (task == "q1-local") run_q1("local", keyword)
  else if (task == "q1-hadoop") run_q1("hadoop", keyword)
  else if (task == "q1-mapper") mapper()
  else if (task == "q1-reducer") reducer()
  else if (task == "q2") run_q2()
  else if (task == "q3") run_q3()
  else if (task == "q4-scrape") run_q4(load_to_db = FALSE)
  else if (task == "q4") run_q4(load_to_db = TRUE)
  else stop("Choose q1-local, q1-hadoop, q2, q3, q4-scrape, or q4.")
}
